from process import Process

if __name__ == "__main__":
    obj = Process()
    obj.whole_process()
