# LinkedIn-Scrapper
The bot searches for job opportunities on LinkedIn based on the given location and job role, and generates a report in both Excel and Google Sheets formats. The report includes details such as job location, job designation, post date, and a link to the job posting.


1. Create Your Json file populated with Your Server Account Credentials and Give the path in the ENV file.
2. Enter Your Google Drive Folder ID
3. Editor Email = Enter Your Server Acoount Mail which have access to edit the sheet